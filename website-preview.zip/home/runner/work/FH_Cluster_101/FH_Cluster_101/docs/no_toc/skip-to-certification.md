


# Skip to Certification {-}

Are you an experienced user? Do you need certification? You can jump straight to the 10-question quiz by clicking the link below. **This Leanpub quiz can be taken for free, but you still have to put the course in your cart and check out**.

[Self-Test: Cluster 101](https://leanpub.com/courses/fredhutch/fredhutchcluster101/quizzes/self_test_101){target="_blank"}

An experienced user:

- Has used SSH to connect to a computing cluster
- Is familiar with the methods used to connect to the Fred Hutch cluster
- Has used Slurm to submit a computing job
- Is familiar with the Cyberduck application for transferring files

<img src="resources/images/skip-to-certification_files/figure-html//1BQxrVYdKZTbpCaF-i_q9w7s9x034lEXpQZDU-Sl09cs_g162fb43cc93_0_0.png" alt="An arrow depicts jumping from the course to a Leanpub certificate." width="70%" style="display: block; margin: auto;" />
